import type { AuthorizationDecision, PaymentAction, SavedWallet } from "./types.js";
import { PaymentError } from "./types.js";

const patterns = new Set(["IMMEDIATE","DEFERRED","RECURRING_PREPAID","RECURRING_POSTPAID","THRESHOLD_PREPAID","THRESHOLD_POSTPAID","SUBSCRIPTION_PREPAID","SUBSCRIPTION_POSTPAID","UNSCHEDULED_PREPAID","UNSCHEDULED_POSTPAID","INSTALLMENT_PREPAID","INSTALLMENT_POSTPAID"]);
const consentFields:readonly (keyof SavedWallet)[] = ["vaultId","consentId","consentVersion","consentDigest","paymentInitiator","usagePattern","usage"];
function redirectOrigin(value:string):string {
  try {
    const url = new URL(value);
    const local = ["localhost","127.0.0.1","[::1]"].includes(url.hostname);
    if(value.length>2048||url.username||url.password||url.hash||!(url.protocol==="https:"||url.protocol==="http:"&&local))throw new Error();
    return url.origin;
  } catch { throw new PaymentError("INVALID_CHECKOUT_URL","Checkout redirects require HTTPS or local development URLs without credentials or fragments.",400); }
}

/** A typed SDK payload is not authorization. Recheck the owning domain's current grant. */
export function assertCheckoutAuthority(action:PaymentAction,decision:AuthorizationDecision,now:Date):void {
  if(action.kind!=="create_order")return;
  if(action.experience){
    const experience=action.experience;
    for(const value of [experience.returnUrl,experience.cancelUrl]){
      if(!decision.checkoutOrigins?.includes(redirectOrigin(value)))throw new PaymentError("CHECKOUT_ORIGIN_NOT_GRANTED","The checkout redirect is outside this project's current approved origins.",403);
    }
    if(!["PAY_NOW","CONTINUE"].includes(experience.userAction)||!["GET_FROM_FILE","NO_SHIPPING"].includes(experience.shippingPreference)||experience.landingPage!==undefined&&!["LOGIN","GUEST_CHECKOUT","NO_PREFERENCE"].includes(experience.landingPage)||experience.brandName!==undefined&&(!experience.brandName.trim()||experience.brandName.length>127)||experience.locale!==undefined&&!/^[a-z]{2}-[A-Z]{2}$/.test(experience.locale))throw new PaymentError("INVALID_CHECKOUT_EXPERIENCE","Review the checkout display and locale settings.",400);
  }
  if(action.savedWallet){
    const wallet=action.savedWallet;const consent=decision.savedWalletConsent;
    if(!/^[a-zA-Z0-9_-]{3,128}$/.test(wallet.vaultId)||!wallet.consentId||!wallet.consentDigest||!Number.isSafeInteger(wallet.consentVersion)||wallet.consentVersion<1||!["CUSTOMER","MERCHANT"].includes(wallet.paymentInitiator)||!patterns.has(wallet.usagePattern)||!["DERIVED","SUBSEQUENT"].includes(wallet.usage))throw new PaymentError("INVALID_WALLET_CONSENT","A saved wallet requires valid consent and charge metadata.",400);
    if(!consent||consentFields.some(field=>consent[field]!==wallet[field])||!Number.isFinite(Date.parse(consent.expiresAt))||Date.parse(consent.expiresAt)<=now.getTime())throw new PaymentError("WALLET_CONSENT_NOT_GRANTED","Current consent does not authorize this saved wallet and charge pattern.",403);
  }
}
