# PayPal core 0.1.0

Portable server-only payment execution, tested first against Fracture Lab's hardened control. Never insert this core into an intentionally faulty target's request path. MIT licensed; no account provisioning or package publication is performed.

The SDK is `paypal` 2.29.0 pinned to `5d0df8a8817e5fdf2e2cd48e68f790ea4730aab2` in `context-plugins/paypal-typescript-sdk`. It is distinct from `@paypal/paypal-server-sdk`. No SDK source is vendored. `PROVENANCE.json` records exact implementation hashes and local conformance results; those tests make no live-provider claim.

## Build and portability

Copy the complete versioned package into the receiving repository, preserving its provenance and license. It has ordinary npm dependencies, no parent-workspace imports, and Node ESM output. Node 22 or later is required.

```sh
npm install
npm run build --prefix packages/paypal-core
npm run verify:core
```

The last command is supplied by Fracture Lab's root scripts. It executes the suite on file-backed SQLite and, when `DATABASE_URL` is configured, PostgreSQL; exercises the real pinned SDK with dummy fetch responses; builds the package; and writes `docs/evidence/core-conformance.json`. PostgreSQL is the authoritative deployment store. There is no process-memory store.

## Frozen interface

Public types are in `src/types.ts`; emitted declarations are in `dist/index.d.ts`. Import from the package root.

- `PaymentCore({store,provider,policy})`: `execute(command)`, explicit `retry(scope,operationId)`, `reconcile(scope,operationId)`, `recover(scope)`, `listReceipts(scope)`, and `ingestWebhook(scope,rawBody,headers,verifier)`.
- `SqlPaymentStore(db)`: call `initialize()` during migration. Claims and transitions use SQL uniqueness, row locks, and versions. The `PaymentStore` adapter also exposes `reclaim` for safe retry with a fresh budget.
- `PostgresDatabase(connectionString)` and `SqliteDatabase(filePath)` implement `SqlDatabase`.
- `SandboxPayPalProvider(config)`: typed SDK writes, normalized resource reads, conservative reconciliation, and scoped Transaction Search. Config requires exact sandbox URL, credentials, and a project-isolation marker.
- `PayPalWebhookVerifier(config,registeredWebhookId)`: REST postback because this SDK has no webhook operation. Simulator placeholder IDs are rejected. Original event JSON is preserved; arbitrary certificate URLs are never downloaded.
- `payloadHash(action)`, `canonicalJson`, exact minor-unit money conversion, and redaction helpers.

Every `PaymentCommand` contains `scope:{tenantId,projectId}`, `operationId`, semantic `businessKey`, `intentId`, `providerRequestId`, immutable `payloadHash(action)`, typed `action`, and `approval:{id,version,digest,expiresAt}`. Repeated callbacks use the same semantic key. Changed payloads and provider-key reuse for another business operation are rejected. The typed SDK field sends `PayPal-Request-Id`; the SDK's generic `Idempotency-Key` is not substituted for it.

The domain implements `PaymentPolicy.authorize(command)` from current durable authority. Return `allowed`, `reason`, `resourceIds`, `currency`, `maximumMinor`, `approvalId`, `approvalVersion`, and **`approvalDigest`**. Checks occur before claim and again before dispatch. All relevant resource IDs must be granted. The domain owns authentication, approvals, payer consent, merchant ownership, and freshness. An unconditional allow is for isolated tests only.

Refund and authorization-capture grants require a fresh `reservation`:

```ts
{
  resourceKey: `capture:${captureId}`, // or authorization:<id>
  currency: 'USD', totalMinor: 1200, externallyConsumedMinor: 300,
  observedProviderIds: ['refund-id-already-in-that-300'],
  observedAt: new Date().toISOString()
}
```

The budget must derive from authoritative reads and complete ownership mapping. `observedProviderIds` names only effects already included in `externallyConsumedMinor`, avoiding duplicate accounting. Atomic claims add unmatched in-flight reservations. Pending and uncertain writes retain capacity. A capture's gross amount or status alone is not its remaining refundable balance. Version 0.1 does not discover a merchant's complete historical refunds for the domain.

## Outcomes and recovery

HTTP success is not completed money movement. Pending captures/refunds, missing resource fields, unavailable rereads, and uncorrelated effects remain `pending_reconciliation`. Definite denied states are `refused`. Authentication/encoding failures known to precede dispatch are `not_sent`. Unknown operations cannot use `retry`.

For `create_order`, `succeeded` means an order exists, not that money moved. Capture/refund actions also require the correct resource terminal state and exact amount. Drive commerce from the normalized resource kind/status, not operation status alone.

Claims commit before dispatch. Result-persistence failure leaves the committed `dispatching` record. A durable worker must schedule `recover(scope)`: expired dispatch leases and uncertainty receive reads, never blind writes. Failure after commit or in attempt logging leaves the canonical operation receipt recoverable. The package creates no background timer.

There is no invented lookup of orders by request ID. Lost create responses without a known order ID stay unknown. A lost refund ID needs an owning order exposing its `customId` correlation; aggregate amounts cannot prove an individual refund. Partial authorization capture also remains unknown without exact attribution. Do not clear these reservations simply to enable another write.

Webhook signature verification, supported minimal reference-envelope validation, and canonical-event deduplication are separate checks. All delivery attempts are retained. Unsupported/malformed verified envelopes and changed canonical payloads become dead letters. Intake never mutates commerce. Domain workers must reread the authoritative resource before a commerce transition.

## Qualification limits

Tests cover durable duplicate claims, changed payloads, refund races, pending/unknown/refused states, SQL failures around provider success, authority revocation, webhook rejection/deduplication/dead letters, exact money, and actual SDK request encoding with fixture responses. Evidence is **Sample**. No credentials or raw provider response bodies are emitted.

Authorization capture/void and Transaction Search have resolved typed implementations but require further endpoint-specific and real-account qualification before product claims. Tracking, disputes, payouts, vault, Toolkit tools, and subscription billing are separate extensions not supplied by 0.1.0. Each product needs its own live receipts, ownership policy, read-API authorization, durable recovery worker, and dead-letter review.

| Surface | Version 0.1.0 status |
|---|---|
| Orders create/get/capture | Present; fixed single purchase unit, custom ID, CAPTURE/AUTHORIZE intent; local SDK wire tests |
| Orders approval UI, return/cancel URLs, experience context, saved payment source | Not supplied; the create action deliberately has no payment-source or experience fields |
| Orders authorize; authorization read, partial capture, finalCapture, void | Typed implementation present; approved money and a locked authorization budget required; full provider lifecycle qualification pending |
| Capture read and partial refund | Present; exact cents, custom operation ID, current domain budget, pending-state handling |
| Refund read/correlation | Present; unknown ID without a matching owning-order refund remains unknown |
| Transaction Search | Present, read-only, bounded/paginated/scoped; entitlement and runtime qualification pending |
| Registered webhook signature postback/intake | Present; receiver route/registration and authentic delivery qualification belong to each app |
| Vault setup approval, payment tokens, saved-wallet checkout | Absent; required by saved-wallet products and must be added as a separately reviewed extension |
| Payouts and recipient payout authority | Absent |
| Invoices, tracking, customer disputes/evidence | Absent |
| Subscriptions and Agent Toolkit tools | Absent |

The Guild must qualify partial captures and `finalCapture` against its authorization ownership and remaining balance. WorldKit and Fieldproof require the missing vault/consent flows; they cannot use a saved token by overloading this release's create-order action. Glasshouse tracking/disputes are also explicit follow-on work.
